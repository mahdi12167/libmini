#define MAP_FILENAME "Yellowstone.map"
#define MAP_S (1<<8)
#define MAP_D (600.0/30)
#define MAP_SCALE (0.1)

#define TEX_MAP_FILENAME "Yellowstone.tex-map.jpg"
#define TEX_MAP_S (1<<8)
