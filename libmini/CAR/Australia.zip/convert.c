#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define N (100)

#define ERROR(str) {printf("%s\n",str); return;}

void main(int argc,char *argv[])
   {
   int i,j,
       w,h,s,
       min,max;

   float c;

   FILE *binfile,*mapfile,*texmapfile,*imgfile;

   char str1[N],str2[N],str3[N],str4[N];

   short int *row;

   if (argc<4 || argc>5) ERROR("usage: convert <bin-file> <width> <height> [+]");

   strncpy(str1,argv[1],N-5);
   strncpy(str2,argv[1],N-5);
   strncpy(str3,argv[1],N-13);
   strncpy(str4,argv[1],N-5);

   sscanf(argv[2],"%d",&w);
   sscanf(argv[3],"%d",&h);

   if (w>h) s=w;
   else s=h;

   if (s<2) ERROR("bad map size!");

   if ((row=malloc(s*2))==NULL) ERROR("malloc error!");

   if ((binfile=fopen(strcat(str1,".bin"),"r"))==NULL) ERROR("could not open bin file!");
   if ((mapfile=fopen(strcat(str2,".map"),"w"))==NULL) ERROR("could not create map file!");
   if ((texmapfile=fopen(strcat(str3,".tex-map.ppm"),"w"))==NULL) ERROR("could not create tex-map file!");
   if ((imgfile=fopen(strcat(str4,".pgm"),"w"))==NULL) ERROR("could not create img file!");

   fprintf(texmapfile,"P6\n%d %d\n255\n",s,s);
   fprintf(imgfile,"P5\n%d %d\n255\n",s,s);

   min=32767;
   max=-32768;

   for (i=0; i<s; i++)
      {
      for (j=0; j<s; j++) row[j]=0;

      if (2*i>=s-h && 2*(i-h)<s-h)
         if (fread(&row[(s-w)/2],w*2,1,binfile)!=1) ERROR("read error!");

      if (argc==5)
         if (*argv[4]=='+')
            for (j=0; j<s; j++) row[j]=((row[j]>>8)&255)|((row[j]&255)<<8);

      for (j=0; j<s; j++)
         if (row[j]<min) min=row[j];
         else if (row[j]>max) max=row[j];

      if (fwrite(row,s*2,1,mapfile)!=1) ERROR("write error!");
      }

   fclose(binfile);
   fclose(mapfile);

   if ((mapfile=fopen(str2,"r"))==NULL) ERROR("could not open map file!");

   for (i=0; i<s; i++)
      {
      if (fread(row,s*2,1,mapfile)!=1) ERROR("read error!");

      for (j=0; j<s; j++)
         {
         if (row[j]<0) c=row[j]/(float)-min;
         else if (max>0) c=row[j]/(float)max;
         else c=0.0;

         if (c<=0.0)
            {
            fputc(-c*128,texmapfile);
            fputc((1.0+c)*16,texmapfile);
            fputc(64,texmapfile);
            }
         else if (c<0.25)
            {
            fputc(0,texmapfile);
            fputc((0.5-c)*64*4,texmapfile);
            fputc(32,texmapfile);
            }
         else if (c<0.5)
            {
            fputc((c-0.25)*64*4,texmapfile);
            fputc(64,texmapfile);
            fputc(32,texmapfile);
            }
         else if (c<0.75)
            {
            fputc(64,texmapfile);
            fputc(64,texmapfile);
            fputc(32+(c-0.5)*64*4,texmapfile);
            }
         else
            {
            fputc(64+(c-0.75)*96*4,texmapfile);
            fputc(64+(c-0.75)*96*4,texmapfile);
            fputc(96+(c-0.75)*64*4,texmapfile);
            }

         if (min!=max) fputc(255*(row[j]-min)/(max-min),imgfile);
         else fputc(0,imgfile);
         }
      }

   fclose(mapfile);
   fclose(texmapfile);
   fclose(imgfile);

   printf("size=%d, min=%d, max=%d\n",s,min,max);
   }
