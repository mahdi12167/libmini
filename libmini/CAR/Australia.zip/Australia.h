#define MAP_FILENAME "Australia.map"
#define MAP_S (505)
#define MAP_D (10000.0/200)
#define MAP_SCALE (0.1)

#define TEX_MAP_FILENAME "Australia.tex-map.jpg"
#define TEX_MAP_S (1<<8)
