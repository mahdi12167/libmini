#define MAP_FILENAME "Yukon.map"
#define MAP_S (243)
#define MAP_D (100.0/3)
#define MAP_SCALE (3.0)

#define TEX_MAP_FILENAME "Yukon.tex-map.jpg"
#define TEX_MAP_S (1<<8)
